import 'package:flutter/material.dart';

import '../../../app/theme/app_colors.dart';
import '../../../core/formatters/money_formatter.dart';
import '../../../core/models/dashboard_snapshot.dart';
import '../../../core/models/goal.dart';
import '../../../core/models/family.dart';
import '../../../core/widgets/goal_progress_card.dart';

class HomeSurface extends StatelessWidget {
  const HomeSurface({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
  });
  final Widget child;
  final EdgeInsetsGeometry padding;
  @override
  Widget build(BuildContext context) => Container(
    padding: padding,
    decoration: BoxDecoration(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: const Color(0xFFDED9CB)),
      boxShadow: const [
        BoxShadow(
          color: Color(0x07000000),
          blurRadius: 10,
          offset: Offset(0, 3),
        ),
      ],
    ),
    child: child,
  );
}

class HomeMonthlySummary extends StatelessWidget {
  const HomeMonthlySummary({
    super.key,
    required this.snapshot,
    required this.onTap,
    this.onYear,
    this.onMonth,
    this.onPrevious,
    this.onNext,
  });
  final MonthlyTotals snapshot;
  final VoidCallback onTap;
  final VoidCallback? onYear, onMonth, onPrevious, onNext;
  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final current =
        snapshot.month.year == now.year && snapshot.month.month == now.month;
    return HomeSurface(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Wrap(
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  if (onPrevious != null)
                    IconButton(
                      tooltip: '上个月',
                      onPressed: onPrevious,
                      icon: const Icon(Icons.chevron_left, size: 20),
                    ),
                  TextButton(
                    key: const ValueKey('home-year-picker'),
                    onPressed: onYear,
                    style: TextButton.styleFrom(
                      foregroundColor: AppColors.textPrimary,
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      minimumSize: const Size(64, 44),
                    ),
                    child: Text(
                      '${snapshot.month.year}年',
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  TextButton(
                    key: const ValueKey('home-month-picker'),
                    onPressed: onMonth,
                    style: TextButton.styleFrom(
                      foregroundColor: AppColors.primaryDark,
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      minimumSize: const Size(44, 44),
                    ),
                    child: Text(
                      '${snapshot.month.month}月⌄',
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  if (onPrevious != null)
                    IconButton(
                      tooltip: '下个月',
                      onPressed: onNext,
                      icon: const Icon(Icons.chevron_right, size: 20),
                    ),
                ],
              ),
              TextButton(
                onPressed: onTap,
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  minimumSize: const Size(70, 44),
                ),
                child: Text(
                  current ? '本月账单 ›' : '${snapshot.month.month}月账单 ›',
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                  ),
                ),
              ),
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _metric('收入', snapshot.income, AppColors.primaryDark),
              _metric('支出', snapshot.expense, AppColors.textPrimary),
              _metric('收支结余', snapshot.forecastBalance, AppColors.textPrimary),
            ],
          ),
        ],
      ),
    );
  }

  Widget _metric(String title, double amount, Color color) => Expanded(
    child: Padding(
      padding: const EdgeInsets.only(right: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 11,
            ),
          ),
          const SizedBox(height: 3),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              '¥ ${MoneyFormatter.decimal(amount)}',
              style: TextStyle(
                fontSize: 18,
                color: color,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

class HomeSpendingGoalCard extends StatelessWidget {
  const HomeSpendingGoalCard({
    super.key,
    required this.snapshot,
    this.goal,
    required this.onBudget,
    required this.onGoal,
    required this.onCalculation,
    this.bookType = BookType.personal,
  });
  final DashboardSnapshot snapshot;
  final Goal? goal;
  final VoidCallback onBudget, onGoal, onCalculation;
  final BookType bookType;
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      Container(
        key: const ValueKey('home-spending-card'),
        decoration: BoxDecoration(
          color: const Color(0xFFF1F4E4),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFCBD8AC)),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 8, 10),
          child: Row(
            children: [
              Expanded(
                child: Semantics(
                  button: true,
                  label: '${bookType.spendingLabel}，打开预算管理',
                  child: InkWell(
                    key: const ValueKey('home-budget-area'),
                    onTap: onBudget,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          bookType.spendingLabel,
                          style: const TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 2),
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            snapshot.hasBudget
                                ? '¥ ${MoneyFormatter.decimal(snapshot.safeToSpend)}'
                                : '未设置预算',
                            style: TextStyle(
                              color: snapshot.availableAmount < 0
                                  ? AppColors.warning
                                  : AppColors.primaryDark,
                              fontSize: snapshot.hasBudget ? 30 : 21,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        Text(
                          snapshot.hasBudget
                              ? '${snapshot.month.month}月预算 · 剩余 ${snapshot.remainingDays} 天${snapshot.availableAmount < 0 ? ' · 已超预算' : ''}'
                              : '设置本月预算后计算 ›',
                          style: const TextStyle(
                            color: AppColors.primaryDark,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              IconButton(
                key: const ValueKey('home-calculation'),
                tooltip: '查看计算依据',
                onPressed: onCalculation,
                icon: const Icon(
                  Icons.info_outline,
                  color: AppColors.primaryDark,
                  size: 22,
                ),
              ),
            ],
          ),
        ),
      ),
      const SizedBox(height: 12),
      if (goal != null)
        Semantics(
          button: true,
          label: '打开目标${goal!.name}',
          child: GoalProgressCard(
            key: const ValueKey('home-goal-area'),
            goal: goal!,
            onTap: onGoal,
          ),
        )
      else
        HomeSurface(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          child: InkWell(
            key: const ValueKey('home-goal-area'),
            onTap: onGoal,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Row(
                children: [
                  const Icon(
                    Icons.flag_outlined,
                    color: AppColors.primaryDark,
                    size: 21,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      bookType == BookType.enterprise
                          ? '设一个经营目标'
                          : bookType == BookType.family
                          ? '设一个家庭目标'
                          : '设一个正在努力的目标',
                      style: const TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 13,
                      ),
                    ),
                  ),
                  const Icon(Icons.chevron_right, color: AppColors.primaryDark),
                ],
              ),
            ),
          ),
        ),
    ],
  );
}
