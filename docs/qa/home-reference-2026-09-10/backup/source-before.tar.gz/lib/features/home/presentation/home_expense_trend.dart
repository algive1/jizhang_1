import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/theme/app_colors.dart';
import '../../../core/formatters/money_formatter.dart';
import '../../../core/models/analysis.dart';
import '../../../core/widgets/sliding_segmented_control.dart';
import '../../analysis/data/analysis_repository.dart';
import 'home_cards.dart';

class HomeExpenseTrend extends ConsumerStatefulWidget {
  const HomeExpenseTrend({super.key});
  @override
  ConsumerState<HomeExpenseTrend> createState() => _HomeExpenseTrendState();
}

class _HomeExpenseTrendState extends ConsumerState<HomeExpenseTrend> {
  AnalysisPeriod _period = AnalysisPeriod.currentMonth;
  int? _selected;

  @override
  Widget build(BuildContext context) {
    final snapshot = ref
        .watch(analysisRepositoryProvider)
        .analyze(period: _period);
    final points = _period == AnalysisPeriod.currentYear
        ? _monthlyPoints(snapshot.cashflowTrend)
        : snapshot.cashflowTrend;
    final selected = (_selected ?? points.length - 1)
        .clamp(0, math.max(0, points.length - 1))
        .toInt();
    final point = points.isEmpty ? null : points[selected];
    final year = _period == AnalysisPeriod.currentYear;
    String dateLabel(CashflowPoint p) => year
        ? '${p.date.year}年${p.date.month}月'
        : '${p.date.month}月${p.date.day}日';
    return HomeSurface(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  '支出趋势',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
              ),
              SizedBox(
                width: 132,
                child: SlidingSegmentedControl<AnalysisPeriod>(
                  compact: true,
                  keyPrefix: 'home-trend',
                  items: const [
                    (AnalysisPeriod.last7Days, '周'),
                    (AnalysisPeriod.currentMonth, '月'),
                    (AnalysisPeriod.currentYear, '年'),
                  ],
                  selected: _period,
                  onChanged: (period) => setState(() {
                    _period = period;
                    _selected = null;
                  }),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Wrap(
            spacing: 8,
            runSpacing: 2,
            children: [
              Text(
                switch (_period) {
                  AnalysisPeriod.last7Days => '近7天 · 按日',
                  AnalysisPeriod.currentYear => '本年 · 按月',
                  _ => '本月 · 按日',
                },
                style: const TextStyle(
                  color: AppColors.textSecondary,
                  fontSize: 10,
                ),
              ),
              Text(
                point == null
                    ? '暂无记录'
                    : '${dateLabel(point)}  ¥${MoneyFormatter.decimal(point.expense)}',
                key: const ValueKey('home-trend-value'),
                style: const TextStyle(
                  color: AppColors.primaryDark,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (points.isNotEmpty)
            LayoutBuilder(
              builder: (context, constraints) {
                void select(double dx) {
                  final ratio =
                      ((dx - 38) / math.max(1, constraints.maxWidth - 48))
                          .clamp(0, 1);
                  setState(
                    () => _selected = (ratio * (points.length - 1)).round(),
                  );
                }

                return Semantics(
                  label: '支出趋势，${year ? "按月" : "按日"}查看',
                  value:
                      '${dateLabel(point!)}，${MoneyFormatter.decimal(point.expense)}元',
                  increasedValue: selected < points.length - 1
                      ? dateLabel(points[selected + 1])
                      : null,
                  decreasedValue: selected > 0
                      ? dateLabel(points[selected - 1])
                      : null,
                  onIncrease: selected < points.length - 1
                      ? () => setState(() => _selected = selected + 1)
                      : null,
                  onDecrease: selected > 0
                      ? () => setState(() => _selected = selected - 1)
                      : null,
                  child: GestureDetector(
                    key: const ValueKey('home-trend-chart'),
                    behavior: HitTestBehavior.opaque,
                    onTapDown: (event) => select(event.localPosition.dx),
                    onHorizontalDragStart: (event) =>
                        select(event.localPosition.dx),
                    onHorizontalDragUpdate: (event) =>
                        select(event.localPosition.dx),
                    child: SizedBox(
                      height: 132,
                      width: double.infinity,
                      child: CustomPaint(
                        painter: _ExpensePainter(
                          points: points,
                          selected: selected,
                          year: year,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          if (snapshot.expenseCount == 0)
            const Padding(
              padding: EdgeInsets.only(top: 6),
              child: Text(
                '这段时间还没有支出，记下一笔就能看到变化',
                style: TextStyle(color: AppColors.textSecondary, fontSize: 11),
              ),
            ),
        ],
      ),
    );
  }

  List<CashflowPoint> _monthlyPoints(List<CashflowPoint> daily) {
    final amounts = <DateTime, int>{};
    for (final p in daily) {
      final month = DateTime(p.date.year, p.date.month);
      amounts.update(
        month,
        (cents) => cents + (p.expense * 100).round(),
        ifAbsent: () => (p.expense * 100).round(),
      );
    }
    return amounts.entries
        .map((entry) => CashflowPoint(entry.key, 0, entry.value / 100))
        .toList();
  }
}

class _ExpensePainter extends CustomPainter {
  const _ExpensePainter({
    required this.points,
    required this.selected,
    required this.year,
  });
  final List<CashflowPoint> points;
  final int selected;
  final bool year;

  @override
  void paint(Canvas canvas, Size size) {
    const left = 38.0;
    const top = 10.0;
    final width = math.max(1.0, size.width - left - 10);
    final bottom = size.height - 25;
    final height = bottom - top;
    final maxAmount = points.fold<double>(0, (v, p) => math.max(v, p.expense));
    final ceiling = math.max(2.0, maxAmount * 1.2);
    Offset position(int i) => Offset(
      left + width * (points.length == 1 ? .5 : i / (points.length - 1)),
      bottom - points[i].expense / ceiling * height,
    );
    final grid = Paint()
      ..color = const Color(0xFFDCECEB)
      ..strokeWidth = .8;
    for (var i = 0; i < 3; i++) {
      final y = top + i * height / 2;
      for (var x = left; x < size.width - 10; x += 7) {
        canvas.drawLine(
          Offset(x, y),
          Offset(math.min(x + 3, size.width - 10), y),
          grid,
        );
      }
      final amount = ceiling * (1 - i / 2);
      final label = amount >= 10000
          ? '${(amount / 10000).toStringAsFixed(1)}万'
          : MoneyFormatter.whole(amount);
      _label(canvas, label, Offset(0, y - 6), maxWidth: 35);
    }
    final line = Path()..moveTo(position(0).dx, position(0).dy);
    for (var i = 1; i < points.length; i++) {
      line.lineTo(position(i).dx, position(i).dy);
    }
    final area = Path.from(line)
      ..lineTo(position(points.length - 1).dx, bottom)
      ..lineTo(position(0).dx, bottom)
      ..close();
    canvas.drawPath(
      area,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0x553BC9AD), Color(0x063BC9AD)],
        ).createShader(Rect.fromLTWH(left, top, width, height)),
    );
    canvas.drawPath(
      line,
      Paint()
        ..color = AppColors.primary
        ..strokeWidth = 2
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );
    if (points.length < 33) {
      for (var i = 0; i < points.length; i++) {
        canvas.drawCircle(position(i), 2, Paint()..color = AppColors.primary);
      }
    }
    final current = position(selected);
    canvas.drawLine(
      Offset(current.dx, top),
      Offset(current.dx, bottom),
      Paint()
        ..color = const Color(0x77498DF0)
        ..strokeWidth = 1,
    );
    canvas.drawCircle(current, 7, Paint()..color = const Color(0x225499F7));
    canvas.drawCircle(current, 4, Paint()..color = const Color(0xFF489CF2));
    canvas.drawCircle(
      current,
      4,
      Paint()
        ..color = Colors.white
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );
    final labels = <int>{
      0,
      ((points.length - 1) / 3).round(),
      (2 * (points.length - 1) / 3).round(),
      points.length - 1,
    };
    for (final i in labels) {
      final date = points[i].date;
      _label(
        canvas,
        year ? '${date.month}月' : '${date.month}/${date.day}',
        Offset(
          (position(i).dx - 13).clamp(left - 8, size.width - 33),
          bottom + 10,
        ),
        maxWidth: 40,
      );
    }
  }

  void _label(
    Canvas canvas,
    String text,
    Offset offset, {
    required double maxWidth,
  }) {
    final painter = TextPainter(
      text: TextSpan(
        text: text,
        style: const TextStyle(color: AppColors.textSecondary, fontSize: 9),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: maxWidth);
    painter.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant _ExpensePainter old) =>
      old.points != points || old.selected != selected || old.year != year;
}
