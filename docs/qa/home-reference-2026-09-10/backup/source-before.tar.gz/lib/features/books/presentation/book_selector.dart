import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/theme/app_colors.dart';
import '../../../core/database/database_seeder.dart';
import '../../../core/models/book.dart';
import '../../../core/models/family.dart';
import '../../../core/models/membership.dart';
import '../../membership/data/membership_repository.dart';
import '../data/book_repository.dart';

class BookSelectorButton extends ConsumerWidget {
  const BookSelectorButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final book = ref.watch(activeBookProvider);
    return Semantics(
      button: true,
      label: '切换账本',
      child: InkWell(
        onTap: () => showBookSelectorSheet(context, ref),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Flexible(
                child: Text(
                  book?.name ?? '选择账本',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const Icon(
                Icons.keyboard_arrow_down_rounded,
                size: 18,
                color: AppColors.textSecondary,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Future<void> showBookSelectorSheet(BuildContext context, WidgetRef ref) async {
  await showGeneralDialog<void>(
    context: context,
    barrierDismissible: true,
    barrierLabel: '关闭账本书架',
    barrierColor: Colors.black45,
    transitionDuration: MediaQuery.disableAnimationsOf(context)
        ? Duration.zero
        : const Duration(milliseconds: 240),
    transitionBuilder: (context, animation, secondary, child) =>
        SlideTransition(
          position: Tween(begin: const Offset(0, -1), end: Offset.zero).animate(
            CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
          ),
          child: child,
        ),
    pageBuilder: (context, animation, secondary) => const SafeArea(
      child: Align(alignment: Alignment.topCenter, child: _BookSelectorSheet()),
    ),
  );
}

class _BookSelectorSheet extends ConsumerStatefulWidget {
  const _BookSelectorSheet();
  @override
  ConsumerState<_BookSelectorSheet> createState() => _BookSelectorSheetState();
}

class _BookSelectorSheetState extends ConsumerState<_BookSelectorSheet> {
  bool _switching = false;
  @override
  Widget build(BuildContext context) {
    final booksState = ref.watch(booksProvider);
    final membership = ref.watch(membershipProvider).value;
    final limit = BookLimitPolicy.forPlan(
      membership?.membership.plan ?? MembershipPlan.free,
    );
    final books = booksState.value ?? const <LedgerBook>[];
    final ownedCount = books
        .where((b) => !b.isShared || b.role == 'owner')
        .length;
    final width = MediaQuery.sizeOf(context).width;
    final largeText = MediaQuery.textScalerOf(context).scale(14) > 18;
    final columns = width < 360 || largeText ? 2 : 3;
    return Material(
      color: AppColors.background,
      elevation: 18,
      shadowColor: Colors.black54,
      borderRadius: const BorderRadius.vertical(bottom: Radius.circular(24)),
      clipBehavior: Clip.antiAlias,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: 600,
          maxHeight: MediaQuery.sizeOf(context).height * .72,
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 4,
                  decoration: BoxDecoration(
                    color: const Color(0xFFC9B99D),
                    borderRadius: BorderRadius.circular(4),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x24000000),
                        blurRadius: 2,
                        offset: Offset(0, 1),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 7),
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      '我的账本',
                      style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: '关闭书架',
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              Text(
                '选择一本，专心记录这一部分生活',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 16),
              Flexible(
                child: booksState.when(
                  loading: () => const Padding(
                    padding: EdgeInsets.all(24),
                    child: Center(child: CircularProgressIndicator()),
                  ),
                  error: (error, stack) => TextButton(
                    onPressed: () => ref.invalidate(booksProvider),
                    child: const Text('账本读取失败，点击重试'),
                  ),
                  data: (books) => ListView.builder(
                    shrinkWrap: true,
                    itemCount: (books.length / columns).ceil(),
                    itemBuilder: (context, row) => Padding(
                      padding: const EdgeInsets.only(bottom: 20),
                      child: Column(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              color: const Color(0xFFF3E9D8),
                              borderRadius: const BorderRadius.vertical(
                                top: Radius.circular(9),
                              ),
                              border: Border.all(
                                color: const Color(0xFFE4D6BE),
                              ),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x0F000000),
                                  blurRadius: 5,
                                  offset: Offset(0, 2),
                                ),
                              ],
                            ),
                            padding: const EdgeInsets.fromLTRB(4, 8, 4, 0),
                            child: Column(
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    for (var col = 0; col < columns; col++)
                                      Expanded(
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 5,
                                          ),
                                          child:
                                              row * columns + col >=
                                                  books.length
                                              ? const SizedBox.shrink()
                                              : _BookCover(
                                                  book:
                                                      books[row * columns +
                                                          col],
                                                  selected:
                                                      books[row * columns + col]
                                                          .id ==
                                                      ref.watch(
                                                        activeBookIdProvider,
                                                      ),
                                                  height: largeText ? 212 : 166,
                                                  onSelect: _switching
                                                      ? null
                                                      : () => _select(
                                                          books[row * columns +
                                                              col],
                                                        ),
                                                  onManage: () => _manageBook(
                                                    context,
                                                    ref,
                                                    books[row * columns + col],
                                                  ),
                                                ),
                                        ),
                                      ),
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Container(
                                  height: 13,
                                  decoration: BoxDecoration(
                                    borderRadius: const BorderRadius.vertical(
                                      bottom: Radius.circular(4),
                                    ),
                                    gradient: const LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Color(0xFFE1CBAA),
                                        Color(0xFFC5A77D),
                                      ],
                                    ),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0x35000000),
                                        blurRadius: 5,
                                        offset: Offset(0, 3),
                                      ),
                                    ],
                                  ),
                                  child: const Align(
                                    alignment: Alignment.topCenter,
                                    child: SizedBox(
                                      height: 2,
                                      width: double.infinity,
                                      child: ColoredBox(
                                        color: Color(0x66FFF8EA),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              OutlinedButton.icon(
                onPressed: _switching
                    ? null
                    : ownedCount >= limit
                    ? () => _showLimitMessage(context, membership)
                    : () => _createBook(context, ref),
                icon: const Icon(Icons.add),
                label: Text('新建账本 · $ownedCount/$limit'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _select(LedgerBook book) async {
    setState(() => _switching = true);
    try {
      await ref.read(activeBookIdProvider.notifier).select(book.id);
      if (mounted) Navigator.pop(context);
    } on Object catch (error) {
      if (mounted) {
        setState(() => _switching = false);
        _showError(context, error);
      }
    }
  }

  Future<void> _createBook(BuildContext context, WidgetRef ref) async {
    final type = await _askType(context);
    if (type == null || !context.mounted) return;
    final name = await _askName(context, title: '新建${type.label}');
    if (name == null || !context.mounted) return;
    try {
      final book = await ref
          .read(bookRepositoryProvider)
          .create(name: name, type: type);
      ref.invalidate(booksProvider);
      await ref.read(activeBookIdProvider.notifier).select(book.id);
      if (context.mounted) Navigator.pop(context);
    } on Object catch (error) {
      if (context.mounted) _showError(context, error);
    }
  }

  Future<void> _manageBook(
    BuildContext context,
    WidgetRef ref,
    LedgerBook book,
  ) async {
    final action = await showModalBottomSheet<_BookAction>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              enabled: book.canManage,
              leading: const Icon(Icons.drive_file_rename_outline),
              title: const Text('重命名账本'),
              onTap: () => Navigator.pop(context, _BookAction.rename),
            ),
            if (book.id != SeedIds.personalBook && !book.isShared)
              ListTile(
                leading: const Icon(Icons.style_outlined),
                title: const Text('修改账本类型'),
                onTap: () => Navigator.pop(context, _BookAction.type),
              ),
            if (book.type != BookType.personal)
              ListTile(
                leading: const Icon(Icons.people_outline),
                title: Text(book.isShared ? '成员与同步' : '启用共享'),
                onTap: () => Navigator.pop(context, _BookAction.shared),
              ),
            if (book.id != SeedIds.personalBook &&
                (!book.isShared || book.role == 'owner'))
              ListTile(
                leading: const Icon(Icons.delete_outline),
                title: const Text('删除账本'),
                onTap: () => Navigator.pop(context, _BookAction.delete),
              ),
          ],
        ),
      ),
    );
    if (action == null || !context.mounted) return;
    if (action == _BookAction.shared) {
      final router = GoRouter.of(context);
      await ref.read(activeBookIdProvider.notifier).select(book.id);
      if (context.mounted) Navigator.pop(context);
      router.push('/profile/family');
      return;
    }
    if (action == _BookAction.type) {
      final type = await _askType(context);
      if (type != null) {
        try {
          await ref.read(bookRepositoryProvider).changeType(book.id, type);
        } on Object catch (error) {
          if (context.mounted) _showError(context, error);
        }
      }
      return;
    }
    if (action == _BookAction.rename) {
      final name = await _askName(context, title: '重命名账本', initial: book.name);
      if (name == null || !context.mounted) return;
      try {
        await ref.read(bookRepositoryProvider).rename(book.id, name);
        ref.invalidate(booksProvider);
      } on Object catch (error) {
        if (context.mounted) _showError(context, error);
      }
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除「${book.name}」？'),
        content: const Text('账本会从列表中移除，账本内记录不会再出现在当前统计中。此操作不可在应用内恢复。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('确认删除'),
          ),
        ],
      ),
    );
    if (confirmed != true || !context.mounted) return;
    try {
      await ref.read(bookRepositoryProvider).archive(book.id);
      ref.invalidate(booksProvider);
      final remaining = await ref
          .read(bookRepositoryProvider)
          .getForUser(SeedIds.localUser);
      if (book.id == ref.read(activeBookIdProvider) && remaining.isNotEmpty) {
        await ref
            .read(activeBookIdProvider.notifier)
            .select(remaining.first.id);
      }
      if (context.mounted) Navigator.pop(context);
    } on Object catch (error) {
      if (context.mounted) _showError(context, error);
    }
  }

  Future<String?> _askName(
    BuildContext context, {
    required String title,
    String? initial,
  }) async {
    final controller = TextEditingController(text: initial);
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 40,
          decoration: const InputDecoration(hintText: '例如：旅行、装修、日常'),
          onSubmitted: (value) => Navigator.pop(context, value.trim()),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('保存'),
          ),
        ],
      ),
    );
    controller.dispose();
    return value == null || value.isEmpty ? null : value;
  }

  void _showLimitMessage(BuildContext context, MembershipSnapshot? membership) {
    final plan = membership?.membership.plan.label ?? 'Free';
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text('$plan 方案已达到账本数量上限，会员可创建更多账本。')));
  }

  void _showError(BuildContext context, Object error) {
    final message = error is BookLimitReachedException
        ? '已达到账本数量上限，请升级会员'
        : '操作失败：$error';
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }
}

enum _BookAction { rename, delete, type, shared }

Future<BookType?> _askType(BuildContext context) => showDialog<BookType>(
  context: context,
  builder: (context) => SimpleDialog(
    title: const Text('选择账本用途'),
    children: [
      for (final type in BookType.values)
        SimpleDialogOption(
          onPressed: () => Navigator.pop(context, type),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Text(type.label),
          ),
        ),
    ],
  ),
);

class _BookCover extends StatelessWidget {
  const _BookCover({
    required this.book,
    required this.selected,
    required this.height,
    required this.onSelect,
    required this.onManage,
  });
  final LedgerBook book;
  final bool selected;
  final double height;
  final VoidCallback? onSelect;
  final VoidCallback onManage;
  @override
  Widget build(BuildContext context) {
    final color = switch (book.type) {
      BookType.personal => AppColors.primaryDark,
      BookType.family => const Color(0xFF976537),
      BookType.enterprise => const Color(0xFF44677E),
    };
    final dark = Color.lerp(color, Colors.black, .22)!;
    final light = Color.lerp(color, Colors.white, .34)!;
    return Semantics(
      selected: selected,
      button: true,
      label: '${book.name}，${book.type.label}',
      child: Container(
        height: height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [light, color, dark],
            stops: const [0, .42, 1],
          ),
          borderRadius: const BorderRadius.horizontal(
            left: Radius.circular(4),
            right: Radius.circular(10),
          ),
          border: Border.all(
            color: selected ? Colors.white : Color.lerp(dark, color, .5)!,
            width: selected ? 2 : 1,
          ),
          boxShadow: const [
            BoxShadow(
              color: Color(0x30000000),
              blurRadius: 5,
              offset: Offset(3, 3),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.horizontal(
            left: Radius.circular(4),
            right: Radius.circular(10),
          ),
          child: Stack(
            children: [
              // The spine is kept visibly darker so each item reads as a real
              // book, even when several covers sit side by side.
              Positioned(
                left: 0,
                top: 0,
                bottom: 0,
                width: 13,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [dark, color, light.withValues(alpha: .45)],
                    ),
                    border: Border(
                      right: BorderSide(
                        color: Colors.white.withValues(alpha: .26),
                      ),
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        height: 4,
                        color: Colors.white.withValues(alpha: .22),
                      ),
                      Container(
                        height: 4,
                        color: Colors.white.withValues(alpha: .22),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 13,
                right: 6,
                top: 7,
                bottom: 7,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.white.withValues(alpha: .25),
                    ),
                    borderRadius: const BorderRadius.horizontal(
                      right: Radius.circular(6),
                    ),
                    color: Colors.white.withValues(alpha: .045),
                  ),
                ),
              ),
              Positioned(
                left: 13,
                right: 0,
                top: 0,
                height: 4,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.white.withValues(alpha: .30),
                        Colors.white.withValues(alpha: .04),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned.fill(
                child: InkWell(
                  onTap: onSelect,
                  onLongPress: onManage,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 14, 9, 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          selected
                              ? Icons.check_circle
                              : Icons.menu_book_outlined,
                          size: 24,
                          color: Colors.white.withValues(alpha: .92),
                          shadows: const [
                            Shadow(color: Color(0x55000000), blurRadius: 2),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Expanded(
                          child: Text(
                            book.name,
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              shadows: const [
                                Shadow(color: Color(0x55000000), blurRadius: 2),
                              ],
                            ),
                          ),
                        ),
                        Text(
                          book.type.label,
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: .94),
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          book.sharedPhase == 'promoting'
                              ? '待上传'
                              : book.isShared
                              ? '共享'
                              : '本地',
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: .78),
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 0,
                right: 0,
                child: IconButton(
                  tooltip: '管理${book.name}',
                  onPressed: onManage,
                  icon: Icon(
                    Icons.more_horiz,
                    size: 19,
                    color: Colors.white.withValues(alpha: .92),
                    shadows: const [
                      Shadow(color: Color(0x55000000), blurRadius: 2),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
