import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/theme/app_colors.dart';
import '../../../core/formatters/money_formatter.dart';
import '../../../core/models/budget.dart';
import '../../../core/models/category.dart';
import '../../../core/widgets/app_card.dart';
import '../../categories/data/category_repository.dart';
import '../data/budget_repository.dart';

class BudgetPage extends ConsumerWidget {
  const BudgetPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final overview = ref.watch(budgetOverviewProvider);
    final total = overview.total;
    final categories =
        (ref.watch(categoriesProvider).value ?? const <Category>[])
            .where(
              (item) =>
                  item.type == CategoryType.expense && item.parentId == null,
            )
            .toList();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 120),
        children: [
          Row(
            children: [
              IconButton(
                onPressed: () => context.go('/profile'),
                icon: const Icon(Icons.arrow_back),
              ),
              Expanded(
                child: Text(
                  '预算管理',
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
              ),
              FilledButton.icon(
                onPressed: () => _setBudget(context, ref),
                icon: const Icon(Icons.edit_outlined),
                label: Text(total == null ? '设置' : '调整'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (total == null)
            AppCard(
              child: Column(
                children: [
                  const Icon(
                    Icons.savings_outlined,
                    color: AppColors.primary,
                    size: 44,
                  ),
                  const SizedBox(height: 10),
                  const Text('设置本月预算后，即可计算今日安心可花'),
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: () => _setBudget(context, ref),
                    child: const Text('设置月度预算'),
                  ),
                ],
              ),
            )
          else
            _TotalBudgetCard(progress: total),
          const SizedBox(height: 20),
          Row(
            children: [
              Text('分类预算', style: Theme.of(context).textTheme.titleLarge),
              const Spacer(),
              TextButton.icon(
                onPressed: () =>
                    _setBudget(context, ref, selectableCategories: categories),
                icon: const Icon(Icons.add),
                label: const Text('添加'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (overview.categories.isEmpty)
            const AppCard(
              child: Text(
                '还没有分类预算，可以先从餐饮、交通等高频分类开始。',
                style: TextStyle(color: AppColors.textSecondary),
              ),
            )
          else
            ...overview.categories.map(
              (progress) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _CategoryBudgetCard(
                  progress: progress,
                  onEdit: () => _setBudget(
                    context,
                    ref,
                    existing: progress.budget,
                    selectableCategories: categories,
                  ),
                  onRemove: () => ref
                      .read(budgetRepositoryProvider)
                      .removeBudget(progress.budget.id),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _setBudget(
    BuildContext context,
    WidgetRef ref, {
    Budget? existing,
    List<Category> selectableCategories = const [],
  }) async {
    final amountController = TextEditingController(
      text: existing?.amount.toStringAsFixed(2),
    );
    String? categoryId = existing?.categoryId;
    final result = await showDialog<(double, String?)>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(selectableCategories.isEmpty ? '月度总预算' : '分类预算'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (selectableCategories.isNotEmpty) ...[
                DropdownButtonFormField<String>(
                  initialValue: categoryId,
                  decoration: const InputDecoration(labelText: '分类'),
                  items: selectableCategories
                      .map(
                        (category) => DropdownMenuItem(
                          value: category.id,
                          child: Text(category.name),
                        ),
                      )
                      .toList(),
                  onChanged: existing == null
                      ? (value) => setDialogState(() => categoryId = value)
                      : null,
                ),
                const SizedBox(height: 12),
              ],
              TextField(
                controller: amountController,
                autofocus: true,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: '预算金额',
                  prefixText: '¥ ',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () {
                final amount = double.tryParse(amountController.text);
                if (amount == null || amount <= 0) return;
                if (selectableCategories.isNotEmpty && categoryId == null) {
                  return;
                }
                Navigator.pop(dialogContext, (amount, categoryId));
              },
              child: const Text('保存'),
            ),
          ],
        ),
      ),
    );
    amountController.dispose();
    if (result == null) return;
    await ref
        .read(budgetRepositoryProvider)
        .setBudget(
          monthKey: budgetMonthKey(DateTime.now()),
          amount: result.$1,
          categoryId: selectableCategories.isEmpty ? null : result.$2,
        );
  }
}

class _TotalBudgetCard extends StatelessWidget {
  const _TotalBudgetCard({required this.progress});

  final BudgetProgress progress;

  @override
  Widget build(BuildContext context) {
    final remaining = progress.remaining;
    return AppCard(
      color: const Color(0xFFF2F5E4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                '本月还剩',
                style: TextStyle(color: AppColors.textSecondary),
              ),
              const Spacer(),
              _StatusBadge(status: progress.status),
            ],
          ),
          const SizedBox(height: 7),
          FittedBox(
            child: Text(
              '${remaining < 0 ? '-' : ''}¥${MoneyFormatter.whole(remaining.abs())}',
              style: TextStyle(
                color: remaining < 0
                    ? AppColors.warning
                    : AppColors.primaryDark,
                fontSize: 38,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(height: 12),
          LinearProgressIndicator(
            value: progress.percentage.clamp(0, 1),
            minHeight: 9,
            borderRadius: BorderRadius.circular(8),
            color: progress.status == BudgetAlertStatus.exceeded
                ? AppColors.warning
                : AppColors.primary,
            backgroundColor: AppColors.primarySoft,
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _BudgetStat(
                  label: '已支出',
                  value: '¥${MoneyFormatter.whole(progress.used)}',
                ),
              ),
              Expanded(
                child: _BudgetStat(
                  label: '本月预算',
                  value: '¥${MoneyFormatter.whole(progress.budget.amount)}',
                ),
              ),
              Expanded(
                child: _BudgetStat(
                  label: '日均可用',
                  value: '¥${MoneyFormatter.whole(progress.dailyAvailable)}',
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            '本月还剩 ${progress.remainingDays} 天 · 目标预留 ¥${MoneyFormatter.decimal(progress.goalReservation)}',
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}

class _CategoryBudgetCard extends StatelessWidget {
  const _CategoryBudgetCard({
    required this.progress,
    required this.onEdit,
    required this.onRemove,
  });

  final BudgetProgress progress;
  final VoidCallback onEdit;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
      borderRadius: 18,
      child: Row(
        children: [
          const CircleAvatar(
            backgroundColor: AppColors.primarySoft,
            child: Icon(Icons.category_outlined, color: AppColors.primaryDark),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        progress.category?.name ?? '已隐藏分类',
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                    _StatusBadge(status: progress.status),
                  ],
                ),
                const SizedBox(height: 6),
                LinearProgressIndicator(
                  value: progress.percentage.clamp(0, 1),
                  minHeight: 6,
                  borderRadius: BorderRadius.circular(6),
                  backgroundColor: AppColors.primarySoft,
                ),
                const SizedBox(height: 5),
                Text(
                  '已用 ¥${MoneyFormatter.whole(progress.used)}  ·  '
                  '剩余 ¥${MoneyFormatter.whole(progress.remaining)}',
                  style: const TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          PopupMenuButton<String>(
            onSelected: (value) => value == 'edit' ? onEdit() : onRemove(),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'edit', child: Text('调整')),
              PopupMenuItem(value: 'remove', child: Text('移除')),
            ],
          ),
        ],
      ),
    );
  }
}

class _BudgetStat extends StatelessWidget {
  const _BudgetStat({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(color: AppColors.textSecondary, fontSize: 11),
        ),
        const SizedBox(height: 2),
        FittedBox(
          child: Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
        ),
      ],
    );
  }
}

class _StatusBadge extends StatelessWidget {
  const _StatusBadge({required this.status});

  final BudgetAlertStatus status;

  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (status) {
      BudgetAlertStatus.normal => ('正常', AppColors.primary),
      BudgetAlertStatus.nearLimit => ('接近预算', const Color(0xFFD58A2C)),
      BudgetAlertStatus.exceeded => ('已超预算', AppColors.warning),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .12),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(label, style: TextStyle(color: color, fontSize: 11)),
    );
  }
}
