import 'package:flutter/material.dart';

import '../../app/theme/app_colors.dart';

class CategoryIcon extends StatelessWidget {
  const CategoryIcon({
    required this.category,
    super.key,
    this.size = 46,
    this.vivid = false,
  });

  final String category;
  final double size;
  final bool vivid;

  @override
  Widget build(BuildContext context) {
    final style = vivid
        ? (_vividStyles[category] ?? _vividStyles['其他']!)
        : (_styles[category] ?? _styles['其他']!);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: style.$1,
        borderRadius: BorderRadius.circular(vivid ? size * .32 : size / 2),
      ),
      child: Icon(style.$2, color: style.$3, size: size * .48),
    );
  }

  static Color accentFor(String category) =>
      (_vividStyles[category] ?? _vividStyles['其他']!).$3;
  static const _vividStyles = <String, (Color, IconData, Color)>{
    '餐饮': (Color(0xFFFFF0DF), Icons.restaurant_rounded, Color(0xFFFF973F)),
    '购物': (Color(0xFFFFEAF2), Icons.shopping_bag_rounded, Color(0xFFF75C9A)),
    '交通': (Color(0xFFE7F2FF), Icons.directions_car_rounded, Color(0xFF398FF2)),
    '居家': (Color(0xFFE0F8EF), Icons.home_rounded, Color(0xFF12B992)),
    '住房': (Color(0xFFE0F8EF), Icons.home_rounded, Color(0xFF12B992)),
    '娱乐': (Color(0xFFF0EAFE), Icons.sports_esports_rounded, Color(0xFF9D77EE)),
    '日用': (Color(0xFFEAF2FF), Icons.shopping_cart_rounded, Color(0xFF539AF2)),
    '医疗': (Color(0xFFE3F8F1), Icons.local_hospital_rounded, Color(0xFF19B798)),
    '教育': (Color(0xFFE9F2FF), Icons.school_rounded, Color(0xFF408FE6)),
    '人情': (Color(0xFFFFEDF2), Icons.favorite_rounded, Color(0xFFEF789E)),
    '工资': (Color(0xFFE1F8EF), Icons.work_rounded, Color(0xFF11B690)),
    '收入': (
      Color(0xFFE1F8EF),
      Icons.account_balance_wallet_rounded,
      Color(0xFF11B690),
    ),
    '生活缴费': (Color(0xFFEAF2FF), Icons.receipt_long_rounded, Color(0xFF539AF2)),
    '教育培训': (Color(0xFFE9F2FF), Icons.school_rounded, Color(0xFF408FE6)),
    '旅行': (Color(0xFFE5F5FC), Icons.flight_takeoff_rounded, Color(0xFF38A2C8)),
    '宠物': (Color(0xFFFFEFDE), Icons.pets_rounded, Color(0xFFD29B50)),
    '数码': (Color(0xFFEAF0FF), Icons.devices_rounded, Color(0xFF718EDD)),
    '汽车': (Color(0xFFE7F2FF), Icons.directions_car_rounded, Color(0xFF398FF2)),
    '奖金': (Color(0xFFFFF3D9), Icons.stars_rounded, Color(0xFFE4B345)),
    '兼职': (Color(0xFFE5F6F6), Icons.schedule_rounded, Color(0xFF30AFA6)),
    '投资收益': (Color(0xFFE1F8EF), Icons.trending_up_rounded, Color(0xFF11B690)),
    '退款': (Color(0xFFE9F2FF), Icons.undo_rounded, Color(0xFF408FE6)),
    '其他收入': (Color(0xFFE1F8EF), Icons.add_circle_outline, Color(0xFF11B690)),
    '其他': (Color(0xFFF0F3F7), Icons.more_horiz_rounded, Color(0xFF8799B0)),
  };

  static const _styles = <String, (Color, IconData, Color)>{
    '餐饮': (Color(0xFFEAF0D7), Icons.restaurant, AppColors.primary),
    '交通': (Color(0xFFFFE9DA), Icons.directions_car, AppColors.warning),
    '购物': (Color(0xFFDFF1F5), Icons.shopping_basket, Color(0xFF3A96C5)),
    '娱乐': (Color(0xFFFFF0D2), Icons.local_activity, Color(0xFFE6A01D)),
    '收入': (Color(0xFFE5F1D2), Icons.account_balance_wallet, AppColors.income),
    '其他': (Color(0xFFECEBE5), Icons.more_horiz, AppColors.textSecondary),
  };
}
