abstract final class AppAssets {
  static const homeLivingScene = 'assets/images/home_living_scene.png';
  static const transactionsStillLife =
      'assets/images/transactions_still_life.png';
  static const goalCar = 'assets/images/goal_car.png';
  static const userAvatar = 'assets/images/user_avatar.png';
  static const profileAvatar = 'assets/images/profile_avatar.png';
}
